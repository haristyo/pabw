<?php
    $host="localhost";
    $user="root";
    $pwd="";
    $dbname="tugaspabw";
    $kon=mysqli_connect($host,$user,$pwd,$dbname);
?>